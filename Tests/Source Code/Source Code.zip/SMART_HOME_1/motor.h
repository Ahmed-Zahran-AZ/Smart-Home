/*
 * motor.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Eng Mahmoud Dardery
 */

#ifndef MOTOR_H_
#define MOTOR_H_

void Motor(void);

#endif /* MOTOR_H_ */

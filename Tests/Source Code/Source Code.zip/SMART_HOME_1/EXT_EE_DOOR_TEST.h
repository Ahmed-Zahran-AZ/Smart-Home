/*
 * EXT_EE_DOOR_TEST.h
 *
 *  Created on: Sep 6, 2023
 *      Author: Eng Mahmoud Dardery
 */

#ifndef EXT_EE_DOOR_TEST_H_
#define EXT_EE_DOOR_TEST_H_

void DOOR_Control(void);

#endif /* EXT_EE_DOOR_TEST_H_ */

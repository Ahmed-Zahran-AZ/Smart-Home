/*
 * Timer1.h
 *
 *  Created on: Sep 7, 2023
 *      Author: LordKuro4Life
 */

#ifndef TIMER1_H_
#define TIMER1_H_
void TIMER1_VidInit(void);
void PWM_SetDutyCycle(uint16_t dutyCycle);


#endif /* TIMER1_H_ */

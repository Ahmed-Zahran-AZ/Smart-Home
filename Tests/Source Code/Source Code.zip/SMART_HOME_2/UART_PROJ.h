/*
 * UART_PROJ.h
 *
 *  Created on: Sep 6, 2023
 *      Author: Eng Mahmoud Dardery
 */

#ifndef UART_PROJ_H_
#define UART_PROJ_H_

void control(void);

#endif /* UART_PROJ_H_ */

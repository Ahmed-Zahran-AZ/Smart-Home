/*
 * AC_TempSens.h
 *
 *  Created on: Sep 6, 2023
 *      Author: Eng Mahmoud Dardery
 */

#ifndef AC_TEMPSENS_H_
#define AC_TEMPSENS_H_

void Ac_Control(void);
void Ldr_Control(void);


#endif /* AC_TEMPSENS_H_ */
